// Variáveis principais
let truck; // caminhão
let obstacles = []; // lista de obstáculos
let city; // cidade destino
let score = 0; // pontuação
let gameOver = false; // controle de fim de jogo

function setup() {
  createCanvas(800, 400); // cria o canvas do jogo
  truck = new Truck(); // inicializa o caminhão
  city = new City(); // inicializa a cidade
  obstacles.push(new Obstacle()); // adiciona um obstáculo inicial
}

function draw() {
  background(200, 240, 255); // cor de fundo (céu claro)

  // Verifica se o jogo acabou
  if (gameOver) {
    textAlign(CENTER);
    textSize(32);
    fill(255, 0, 0);
    text("Fim de jogo! Pontuação: " + score, width / 2, height / 2);
    return; // para o jogo
  }

  truck.update(); // atualiza posição do caminhão
  truck.show();   // desenha o caminhão

  city.show(); // desenha a cidade

  // A cada 90 quadros, cria um novo obstáculo
  if (frameCount % 90 === 0) {
    obstacles.push(new Obstacle());
  }

  // Atualiza e desenha todos os obstáculos
  for (let i = obstacles.length - 1; i >= 0; i--) {
    obstacles[i].update();
    obstacles[i].show();

    // Verifica colisão com o caminhão
    if (obstacles[i].hits(truck)) {
      gameOver = true;
    }

    // Remove obstáculos que saíram da tela e soma ponto
    if (obstacles[i].offscreen()) {
      obstacles.splice(i, 1);
      score++;
    }
  }

  // Mostra pontuação na tela
  fill(0);
  textSize(20);
  text("Pontuação: " + score, 10, 30);
}

// Controla o movimento do caminhão com as setas
function keyPressed() {
  if (keyCode === UP_ARROW) {
    truck.move(-1); // sobe
  } else if (keyCode === DOWN_ARROW) {
    truck.move(1); // desce
  }
}

// Classe do caminhão
class Truck {
  constructor() {
    this.x = 50;
    this.y = height / 2;
    this.size = 40;
    this.yspeed = 0;
  }

  update() {
    this.y += this.yspeed; // aplica velocidade vertical
    this.y = constrain(this.y, 0, height - this.size); // evita sair da tela
    this.yspeed = 0; // reseta velocidade
  }

  move(dir) {
    this.yspeed = dir * 10; // define direção (1 ou -1)
  }

  show() {
    fill(150, 75, 0); // cor do caminhão (marrom)
    rect(this.x, this.y, this.size * 2, this.size); // corpo do caminhão
    fill(255); // cor da comida (branca)
    rect(this.x + this.size * 1.5, this.y - 10, 10, 10); // comida no topo
  }
}

// Classe dos obstáculos (ex: buracos ou barreiras)
class Obstacle {
  constructor() {
    this.x = width;
    this.y = random(height - 40); // posição aleatória vertical
    this.w = 20;
    this.h = 40;
    this.speed = 6; // velocidade de movimento
  }

  update() {
    this.x -= this.speed; // move para a esquerda
  }

  offscreen() {
    return this.x < -this.w; // saiu da tela
  }

  hits(truck) {
    // Verifica colisão com o caminhão (retângulo simples)
    return (
      truck.x < this.x + this.w &&
      truck.x + truck.size * 2 > this.x &&
      truck.y < this.y + this.h &&
      truck.y + truck.size > this.y
    );
  }

  show() {
    fill(255, 0, 0); // cor vermelha
    rect(this.x, this.y, this.w, this.h); // desenha o obstáculo
  }
}

// Classe da cidade (objetivo do caminhão)
class City {
  show() {
    fill(100, 200, 100); // cor verde da cidade
    rect(width - 100, 0, 100, height); // cidade à direita da tela
    fill(0);
    textSize(14);
    textAlign(CENTER);
    text("Cidade", width - 50, height / 2); // nome da cidade
  }
}






























